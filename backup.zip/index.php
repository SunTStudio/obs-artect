<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OBS Championship Leaderboard</title>
<style>
:root{--panel:rgba(7,12,25,.91);--line:rgba(71,231,255,.38);--cyan:#47e7ff;--gold:#ffd166;--text:#f4f7ff;--muted:#9caec9;--row:rgba(22,33,55,.92)}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;background:transparent;overflow:hidden;font-family:"Segoe UI",Arial,sans-serif;color:var(--text)}body{padding:24px;display:flex;justify-content:center;align-items:flex-start}
.board{width:1240px;max-width:100%;border:1px solid var(--line);border-radius:16px;overflow:hidden;background:var(--panel);box-shadow:0 12px 36px rgba(0,0,0,.35),0 0 28px rgba(71,231,255,.09);backdrop-filter:blur(8px)}
.topline{height:4px;background:linear-gradient(90deg,#47e7ff,#7c5cff,#ff4fd8)}
header{display:flex;align-items:center;justify-content:space-between;padding:17px 22px 14px;border-bottom:1px solid rgba(255,255,255,.09)}
.eyebrow{font-size:10px;letter-spacing:2.5px;color:var(--cyan);font-weight:800;text-transform:uppercase}h1{font-size:24px;line-height:1.1;margin:5px 0 0;font-weight:900;letter-spacing:.7px}
.live{display:flex;align-items:center;gap:7px;color:#d6ffe5;background:rgba(30,220,120,.12);border:1px solid rgba(30,220,120,.35);border-radius:999px;padding:7px 10px;font-size:10px;font-weight:800;letter-spacing:1px}.dot{width:7px;height:7px;border-radius:50%;background:#45f09b;box-shadow:0 0 10px #45f09b;animation:pulse 1.4s infinite}
#groups{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px;padding:16px 20px 14px}
.group{display:flex;flex-direction:column;background:rgba(14,23,42,.55);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:12px 14px 10px}
.group-title{display:flex;align-items:center;gap:9px;padding:2px 4px 6px;color:var(--cyan);font-size:12px;letter-spacing:1.8px;font-weight:900;text-transform:uppercase}.group-title:after{content:"";height:1px;flex:1;background:linear-gradient(90deg,rgba(71,231,255,.42),transparent)}
.group-sub{color:var(--muted);font-size:9px;letter-spacing:1px;margin:-3px 4px 6px;text-transform:uppercase}
.cols{display:grid;grid-template-columns:44px minmax(0,1fr) 95px 95px;gap:10px;padding:6px 10px;color:var(--muted);font-size:9px;letter-spacing:1.1px;font-weight:800;border-bottom:1px solid rgba(255,255,255,.05);margin-bottom:4px}
.cols span:nth-child(3),.cols span:nth-child(4){text-align:right}
.entry{display:grid;grid-template-columns:44px minmax(0,1fr) 95px 95px;gap:10px;align-items:center;min-height:50px;padding:7px 10px;margin:4px 0;background:var(--row);border:1px solid rgba(255,255,255,.055);border-radius:9px;transition:transform 650ms cubic-bezier(.2,.8,.2,1),opacity 350ms ease,background 350ms ease,border-color 350ms ease;will-change:transform}
.entry.first{background:linear-gradient(90deg,rgba(255,209,102,.18),rgba(22,33,55,.94) 62%);border-color:rgba(255,209,102,.45)}.entry.second{border-left:3px solid #c4d2e8}.entry.third{border-left:3px solid #c88b62}
.rank{font-size:18px;font-weight:900;color:#c4d2e8;text-align:center}.first .rank{color:var(--gold)}
.name{min-width:0;font-size:14px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.2px}
.score{text-align:right;font-size:18px;font-weight:900;font-variant-numeric:tabular-nums;color:#fff}.first .score{color:var(--gold)}
.time{text-align:right;color:var(--muted);font-size:11px;font-variant-numeric:tabular-nums;white-space:nowrap}
.empty{padding:18px 12px;color:var(--muted);font-size:13px;text-align:center}
footer{display:flex;justify-content:space-between;gap:10px;padding:10px 20px 13px;border-top:1px solid rgba(255,255,255,.08);color:var(--muted);font-size:10px;letter-spacing:.5px}#status{color:var(--cyan)}.error{color:#ff9eae!important}
@keyframes pulse{50%{opacity:.4;transform:scale(.85)}}
</style></head>
<body>
<section class="board"><div class="topline"></div>
<header><div><div class="eyebrow">Elementary School Championship</div><h1>CHAMPIONSHIP LEADERBOARD</h1></div><div class="live"><span class="dot"></span> LIVE</div></header>
<div id="groups"><div class="empty">Hubungkan Google Sheets untuk menampilkan peringkat.</div></div>
<footer><span id="status">MENUNGGU DATA</span><span id="updated">AUTO UPDATE • 5 DETIK</span></footer></section>
<script>
// Kolom Google Sheets: Kelas, Nama Tim, Nilai, Waktu Selesai
const SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1_o_bfA7I1VGTlx76ViVOge9bXzvTZhVCeOg-MXnT7Jo/gviz/tq?tqx=out:csv";
const REFRESH_MS = 5000;
const MAX_TEAMS_PER_CLASS = 20;
const groupsEl=document.getElementById("groups"),statusEl=document.getElementById("status"),updatedEl=document.getElementById("updated");
let lastSignature="";
function parseCSV(text){const out=[];let row=[],cell="",quoted=false;for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'&&quoted&&n==='"'){cell+='"';i++}else if(c==='"')quoted=!quoted;else if(c===','&&!quoted){row.push(cell);cell=""}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&n==='\n')i++;row.push(cell);if(row.some(v=>v.trim()!==""))out.push(row);row=[];cell=""}else cell+=c}row.push(cell);if(row.some(v=>v.trim()!==""))out.push(row);return out}
function norm(s){return String(s||"").trim().toLowerCase()}
function parseTimeToSeconds(t){
  if(!t) return Infinity;
  const s = String(t).trim();
  if(!s || s === "-" || s === "—") return Infinity;
  const parts = s.replace(".", ":").split(":").map(Number);
  if(parts.some(isNaN)) return Infinity;
  if(parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if(parts.length === 2) return parts[0] * 3600 + parts[1] * 60;
  return Infinity;
}
function parseData(csv){
  const m = parseCSV(csv.replace(/^\uFEFF/,""));
  if (m.length < 2) return [];

  let headerRowIdx = 0;
  let headerRow = m[0].map(norm);
  const isColHeaderRow = row => row.some(c => ["nama tim", "tim", "nama", "nilai", "skor", "score"].some(t => c.includes(t)));
  if (!isColHeaderRow(headerRow) && m.length > 2 && isColHeaderRow(m[1].map(norm))) {
    headerRowIdx = 1;
    headerRow = m[1].map(norm);
  }

  const isClsCol = s => ["kelas", "class", "kategori", "kelas pertandingan"].some(t => s === t);
  const isNameCol = s => ["nama tim", "tim", "team", "nama", "peserta"].some(t => s.includes(t)) || s === "lower" || s === "upper";
  const isScoreCol = s => ["nilai", "skor", "score", "poin", "points"].some(t => s.includes(t));
  const isTimeCol = s => ["waktu selesai", "waktu", "finish time", "time finished", "selesai", "finish", "time"].some(t => s.includes(t));

  const blocks = [];
  let currentBlock = null;

  for (let c = 0; c < headerRow.length; c++) {
    const val = headerRow[c];
    if (isClsCol(val)) {
      if (currentBlock && currentBlock.nameCol !== -1) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
      if (!currentBlock) currentBlock = { clsCol: c, nameCol: -1, scoreCol: -1, timeCol: -1, startCol: c };
      else currentBlock.clsCol = c;
    } else if (isNameCol(val)) {
      if (currentBlock && currentBlock.nameCol !== -1) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
      if (!currentBlock) currentBlock = { clsCol: -1, nameCol: c, scoreCol: -1, timeCol: -1, startCol: c };
      else currentBlock.nameCol = c;
    } else if (currentBlock) {
      if (isScoreCol(val) && currentBlock.scoreCol === -1) {
        currentBlock.scoreCol = c;
      } else if (isTimeCol(val) && currentBlock.timeCol === -1) {
        currentBlock.timeCol = c;
      }
    }
  }
  if (currentBlock && currentBlock.nameCol !== -1) {
    blocks.push(currentBlock);
  }

  if (blocks.length < 2 && headerRow.length >= 6 && (!blocks[0] || blocks[0].clsCol === -1)) {
    const rightStart = headerRow.length >= 7 && (headerRow[3] === "" || isNaN(Number(m[headerRowIdx + 1]?.[3]))) ? 4 : 3;
    blocks.length = 0;
    blocks.push({ clsCol: -1, nameCol: 0, scoreCol: 1, timeCol: 2, startCol: 0 });
    blocks.push({ clsCol: -1, nameCol: rightStart, scoreCol: rightStart + 1, timeCol: rightStart + 2, startCol: rightStart });
  }

  if (blocks.length === 0) {
    throw Error("Header wajib: Kelas / Nama Tim, Nilai, Waktu Selesai.");
  }

  blocks.forEach((blk, idx) => {
    let clsName = "";
    if (headerRowIdx === 1) {
      const superVal = norm(m[0][blk.nameCol >= 0 ? blk.nameCol : blk.startCol] || "");
      if (superVal.includes("upper")) clsName = "upper";
      else if (superVal.includes("lower")) clsName = "lower";
    }
    const headVal = norm((blk.nameCol >= 0 ? headerRow[blk.nameCol] : "") || "");
    if (!clsName) {
      if (headVal.includes("upper")) clsName = "upper";
      else if (headVal.includes("lower")) clsName = "lower";
    }
    if (!clsName) {
      clsName = idx === 0 ? "lower" : (idx === 1 ? "upper" : "class-" + (idx + 1));
    }
    blk.cls = clsName;
  });

  const results = [];
  const dataRows = m.slice(headerRowIdx + 1);

  dataRows.forEach((r, rowIdx) => {
    blocks.forEach(blk => {
      const name = blk.nameCol >= 0 ? (r[blk.nameCol] || "").trim() : "";
      const scoreRaw = blk.scoreCol >= 0 ? (r[blk.scoreCol] || "") : "";
      const timeRaw = blk.timeCol >= 0 ? (r[blk.timeCol] || "").trim() : "";
      if (!name) return;

      const score = Number(String(scoreRaw || "0").trim().replace(/\s/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", "."));
      if (!Number.isFinite(score)) return;

      let cls = (blk.clsCol >= 0 ? (r[blk.clsCol] || "").trim() : "") || blk.cls;
      if (!cls) cls = blk.cls;

      results.push({
        cls: cls,
        name: name,
        score: score,
        time: timeRaw,
        timeSec: parseTimeToSeconds(timeRaw),
        key: (cls.toLowerCase() + "::" + name.toLowerCase()) || ("row-" + rowIdx + "-" + cls)
      });
    });
  });

  if (results.length > 0) return results;
  throw Error("Format spreadsheet tidak dikenali atau belum ada data tim.");
}
function render(data){const classDefs=[{key:"lower",title:"LOWER CLASS",sub:"KELAS 1–5 SD"},{key:"upper",title:"UPPER CLASS",sub:"KELAS 6 SD"}];const extra=[...new Set(data.map(x=>x.cls))].filter(c=>!["lower","upper"].includes(c.toLowerCase())).sort();extra.forEach(c=>classDefs.push({key:c.toLowerCase(),title:c.toUpperCase()+" CLASS",sub:""}));const grouped=classDefs.map(g=>({...g,items:data.filter(x=>x.cls.toLowerCase()===g.key).sort((a,b)=>(b.score-a.score)||(a.timeSec-b.timeSec)||a.name.localeCompare(b.name)).slice(0,MAX_TEAMS_PER_CLASS)}));const signature=JSON.stringify(grouped.map(g=>[g.key,g.items.map((x,i)=>[x.key,x.score,x.time,i])]));if(signature===lastSignature)return;const oldRects=new Map([...groupsEl.querySelectorAll(".entry")].map(e=>[e.dataset.key,e.getBoundingClientRect()])),oldEls=new Map([...groupsEl.querySelectorAll(".entry")].map(e=>[e.dataset.key,e])),frag=document.createDocumentFragment();grouped.forEach(g=>{const sec=document.createElement("section");sec.className="group";const title=document.createElement("div");title.className="group-title";title.textContent=g.title;sec.appendChild(title);if(g.sub){const sub=document.createElement("div");sub.className="group-sub";sub.textContent=g.sub;sec.appendChild(sub)}const colHead=document.createElement("div");colHead.className="cols";colHead.innerHTML="<span>RANK</span><span>NAMA TIM</span><span>NILAI</span><span>WAKTU SELESAI</span>";sec.appendChild(colHead);if(!g.items.length){const empty=document.createElement("div");empty.className="empty";empty.textContent="Belum ada tim";sec.appendChild(empty)}g.items.forEach((it,i)=>{let e=oldEls.get(it.key);if(!e){e=document.createElement("div");e.className="entry";e.dataset.key=it.key;e.style.opacity="0";e.innerHTML='<div class="rank"></div><div class="name"></div><div class="score"></div><div class="time"></div>'}e.classList.remove("first","second","third");if(i===0)e.classList.add("first");else if(i===1)e.classList.add("second");else if(i===2)e.classList.add("third");e.querySelector(".rank").textContent=String(i+1).padStart(2,"0");e.querySelector(".name").textContent=it.name;e.querySelector(".score").textContent=it.score.toLocaleString("id-ID");e.querySelector(".time").textContent=it.time||"—";e.dataset.key=it.key;sec.appendChild(e)});frag.appendChild(sec)});groupsEl.replaceChildren(frag);[...groupsEl.querySelectorAll(".entry")].forEach(e=>{const old=oldRects.get(e.dataset.key);if(old){const now=e.getBoundingClientRect(),dy=old.top-now.top;if(Math.abs(dy)>1){e.style.transition="none";e.style.transform=`translateY(${dy}px)`;e.getBoundingClientRect();e.style.transition="";requestAnimationFrame(()=>e.style.transform="")}e.style.opacity="1"}else requestAnimationFrame(()=>e.style.opacity="1")});lastSignature=signature}
function resolveCsvUrl(rawUrl){
  let u = (rawUrl || "").trim();
  if(!u.startsWith("https://")) return u;
  if(u.includes("/gviz/tq") || u.includes("/pub?") || u.includes("/export?")) return u;
  const docMatch = u.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if(docMatch && !u.includes("/d/e/2PACX-")){
    const sheetId = docMatch[1];
    const gidMatch = u.match(/[#&?]gid=([0-9]+)/);
    const gid = gidMatch ? gidMatch[1] : "0";
    return `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&gid=${gid}`;
  }
  return u;
}
async function refresh(){
  const targetUrl = resolveCsvUrl(SHEET_CSV_URL);
  if(!targetUrl.startsWith("https://")){statusEl.textContent="SET URL GOOGLE SHEETS";statusEl.classList.add("error");return}
  try{
    const u=targetUrl+(targetUrl.includes("?")?"&":"?")+"t="+Date.now(),r=await fetch(u,{cache:"no-store"});
    if(!r.ok)throw Error("HTTP "+r.status);
    const d=parseData(await r.text());
    if(!d.length)throw Error("Belum ada data tim.");
    render(d);
    statusEl.textContent="TERHUBUNG • "+d.length+" TIM";
    statusEl.classList.remove("error");
    updatedEl.textContent="DIPERBARUI "+new Date().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit",second:"2-digit"});
  }catch(e){
    statusEl.textContent="GAGAL MEMBACA DATA";
    statusEl.classList.add("error");
    updatedEl.textContent=e.message.slice(0,45);
    console.error(e);
  }
}
refresh();setInterval(refresh,REFRESH_MS);
</script></body></html>